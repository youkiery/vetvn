<?php

/**
 * @Project WORK SCHEDULES 4.X
 * @Author PHAN TAN DUNG (phantandung92@gmail.com)
 * @Copyright (C) 2016 PHAN TAN DUNG. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Sat, 11 Jun 2016 23:45:51 GMT
 */

if (!defined('NV_MOD_WORK_SCHEDULES')) {
  die('Stop!!!');
}
$action = $nv_Request->get_string("action", "get/post", "");

if (!empty($action)) {
  $result = array("status" => 0, "notify" => $lang_module["error"]);
  switch ($action) {
    case 'change_confirm':
      $id = $nv_Request->get_string("id", "get/post", "");

      if (!empty($id)) {
        $sql = "select * from `" . WORK_PREFIX . "_row` where id = $id";
        $query = $db->query($sql);
        $work = $query->fetch();

        if (!empty($work)) {
          $result["status"] = 1;
          $confirm = "";
          foreach ($lang_module["confirm_option"] as $key => $value) {
            $select = "";
            if ($key == $work["confirm"]) {
              $select = "selected";
            }
            $confirm .= "<option value='$key' $select>$value</option>";
          }
          $review = "";
          foreach ($lang_module["review_option"] as $key => $value) {
            $select = "";
            if ($key == $work["review"]) {
              $select = "selected";
            }
            $review .= "<option value='$key' $select>$value</option>";
          }
          $result["confirm"] = $confirm;
          $result["review"] = $review;
          $result["note"] = $work["note"];
          $result["notify"] = "";
        }
      }
    break;

    case 'confirm':
      $id = $nv_Request->get_string("id", "get/post", "");
      $confirm = $nv_Request->get_int("confirm", "get/post", 0);
      $review = $nv_Request->get_int("review", "get/post", 0);
      $note = $nv_Request->get_int("note", "get/post", 0);

      if (!empty($id)) {
        $sql = "update `" . WORK_PREFIX . "_row` set confirm = $confirm, review = $review, note = '$note' where id = $id";
        $query = $db->query($sql);

        if ($query) {
          $result["status"] = 1;
          $result["notify"] = $lang_module["saved"];
          $result["list"] = user_manager_list();
        }
      }
    break;

    case 'change_data':
      $list = user_manager_list();
      $result["list"] = $list;
      $result["status"] = 1;
      $result["notify"] = "";
    break;

    case 'my_work':
      $list = user_work_list();
      $result["list"] = $list;
      $result["status"] = 1;
      $result["notify"] = "";
    break;

    case 'get_process':
      $id = $nv_Request->get_string("id", "get/post", "");
      if (!empty($id)) {
        $sql = "select * from `" . WORK_PREFIX . "_row` where id = $id";
        $query = $db->query($sql);
        $work = $query->fetch();
        if (!empty($work)) {
          $result["status"] = 1;
          $result["process"] = $work["process"];
          $result["note"] = $work["note"];
        }
      }
    break;

    case 'change_process':
      $id = $nv_Request->get_string("id", "get/post", "");
      $process = $nv_Request->get_string("process", "get/post", "");
      $note = $nv_Request->get_string("note", "get/post", "");

      if (!empty($id) && !empty($process)) {
        $sql = "select * from `" . WORK_PREFIX . "_row` where id = $id";
        $query = $db->query($sql);
        $work = $query->fetch();
        if (!empty($work) && $work["process"] <= $process) {
          $sql = "update `" . WORK_PREFIX . "_row` set process = $process, note = '$note' where id = $id";
          if ($db->query($sql)) {
            $result["status"] = 1;
            $result["list"] = user_work_list();
            $result["notify"] = $lang_module["saved"];
          }
        }
      }
      break;
  }
  echo json_encode($result);
  die();
}

$xtpl = new XTemplate('user.tpl', NV_ROOTDIR . '/themes/' . $global_config['module_theme'] . '/modules/' . $module_file);
$xtpl->assign("lang", $lang_module);

$xtpl->assign("depart_list", user_main_list());
$xtpl->assign("content", user_work_list());
$xtpl->parse("main");
$contents = $xtpl->text();

include NV_ROOTDIR . '/includes/header.php';
echo nv_site_theme($contents);
include NV_ROOTDIR . '/includes/footer.php';
