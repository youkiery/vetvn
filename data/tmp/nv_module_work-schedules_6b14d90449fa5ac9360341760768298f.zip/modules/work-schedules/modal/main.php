<?php
  include_once(NV_ROOTDIR . "/modules/" . $module_name . "/modal/config.php");
  $modal_config = new Config();
  include_once(NV_ROOTDIR . "/modules/" . $module_name . "/modal/depart.php");
  include_once(NV_ROOTDIR . "/modules/" . $module_name . "/modal/employ.php");
  include_once(NV_ROOTDIR . "/modules/" . $module_name . "/modal/work.php");
