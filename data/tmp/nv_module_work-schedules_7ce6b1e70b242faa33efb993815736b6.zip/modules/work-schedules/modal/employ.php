<?php
class Employ {
  function __construct() {
    
  }
}