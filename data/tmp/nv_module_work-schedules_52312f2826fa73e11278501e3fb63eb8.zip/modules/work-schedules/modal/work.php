<?php
class Work {
  function __construct() {
    
  }
}