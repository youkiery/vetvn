<?php

$lang_translator['author'] = "Chistua (hchieuthua@gmail.com)";
$lang_translator['createdate'] = "21/03/2019, 13:15";
$lang_translator['copyright'] = "@Copyright (C) 2019";
$lang_translator['info'] = "";
$lang_translator['langtype'] = "lang_module";

