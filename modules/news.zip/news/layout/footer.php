<?php 
include_once "modules/news/template/review.tpl";
echo '</body>
</html>';
?>
